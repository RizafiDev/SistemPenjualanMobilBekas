<?php
namespace App\Filament\Resources\VarianResource\Api\Handlers;

use Illuminate\Http\Request;
use Rupadana\ApiService\Http\Handlers;
use App\Filament\Resources\VarianResource;
use App\Filament\Resources\VarianResource\Api\Requests\CreateVarianRequest;

class CreateHandler extends Handlers {
    public static string | null $uri = '/';
    public static string | null $resource = VarianResource::class;

    public static function getMethod()
    {
        return Handlers::POST;
    }

    public static function getModel() {
        return static::$resource::getModel();
    }

    /**
     * Create Varian
     *
     * @param CreateVarianRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function handler(CreateVarianRequest $request)
    {
        $model = new (static::getModel());

        $model->fill($request->all());

        $model->save();

        return static::sendSuccessResponse($model, "Successfully Create Resource");
    }
}


